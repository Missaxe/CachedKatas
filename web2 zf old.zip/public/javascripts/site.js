function validateEmail() {
    const emailInput = document.getElementById('email');
    const emailValue = emailInput.value;

    const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    if (regex.test(emailValue)) {
        emailInput.classList.remove('invalid');  // Supprimer la classe "invalid" si l'email est valide
        emailInput.classList.add('valid');       // Ajouter la classe "valid"
    } else {
        emailInput.classList.remove('valid');   // Supprimer la classe "valid" si l'email n'est pas valide
        emailInput.classList.add('invalid');    // Ajouter la classe "invalid"
    }
}