## ES6 Kata

Hi, with the following questions, we're gonna asses your basic level in javascript, let's go =)

You must commit after each step. 

The assert line in every test file must not be modified

### `Step 0`

Start the program and run the tests, the tests will fail and that's ok, you will correct them as the test runs through

### `Step 1`

You will need to manipulate an object and returning the right number.

The data is set in Step1.test and the file must not be modified, only the Step1 file should change.

### `Step 2`

In this step you make an API call and handle the response.

The api file in the Step2 folder must not be modified but you can edit Step2 and Step2.test to get things done.

### `Step 3`

Now let's fiddle a bit with functions.

The test is valid but you should convert the Step3 file to use an arrow function rather than a classic function.

### `Step 4`

Now we will begin to explore React.

Inside the `<body>` tag in the App component display a List of Item with the following values : rock, paper, shotgun. 

Use the components in the Step4 Folder.


### `Step 5`

Let's dive a little deeper in React!

You now need to update the previous components to grab the data from a simulated api call. Use the api file in the Step5 folder to get the data
