import React, { useEffect, useState } from 'react';
import './App.css';
import List from '../Step4/List';
import Item from '../Step4/Item';
import { api } from '../Step5/api';

export default function App() {
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async() => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await api();
      setData(result);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => { fetchData(); }, []);

  return (
    <div className="App">
      <header className="App-header">
        <p>Hello! We're gonna do some Javascript!</p>
      </header>
      <body>
        {isLoading && <p>Loading...</p>}
        {error && <p style={{ clor: "red" }}>error {error}</p>}
        { data && (
          <List>
            {
              data.map((item, idx) => (
                <Item key={item} name={item}/>
              ))
            }
          </List>
        )}
      </body>
    </div>
  );
}
