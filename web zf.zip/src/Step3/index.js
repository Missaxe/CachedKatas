export default () => {
    const data = [1, 2, 3, 4, 5, 6];
    const res = data.filter((i) => i === 1);
    return res[0];
};