import { api } from './api'

export default () => {
  const name = 'serviette';
  const id = 1;
  return api(name, id);
}
