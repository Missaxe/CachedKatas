export const api = (name, id) => Promise.resolve({name: name, id: id})
