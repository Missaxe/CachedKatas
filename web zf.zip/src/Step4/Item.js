import React from 'react'

export default ({name}) =>
  <li>{name}</li>
  