export const api = () => Promise.resolve(['violet', 'rose', 'iris'])
