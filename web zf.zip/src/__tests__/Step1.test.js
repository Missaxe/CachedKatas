import Step1 from '../Step1'

///Read the instruction in the README at the root of the project

describe('A basic calculator', () => {
  test('sum every even number from 1 to 9', () => {
    const data = [{ nb: 1 }, { nb: 2 }, { nb: 3 }, { nb: 4 }, { nb: 5 }, { nb: 6 }, { nb: 7 }, { nb: 8 }, { nb: 9 }]
    const res = Step1(data)
    expect(res).toBe(20)
  })
})
