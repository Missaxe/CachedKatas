
export default (data) => {
  console.log(data);
  return data
    .filter(e => e.nb % 2 === 0)  
    .reduce((acc, curr) => acc + curr.nb, 0);
}
