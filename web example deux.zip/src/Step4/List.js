import React from 'react'

const style = {
  width: '20%',
  justifyContent: 'center',
  alignContent: 'center',
  backgroundColor: 'grey',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center'
}

export default ({children}) =>
  <div style={style}>
    <div>My List</div>
    <ul>
    {children}
    </ul>
  </div>
  