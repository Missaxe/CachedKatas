import { api } from './api'

export default async () => {
  const name = 'serviette';
  const id = 1;
  var a = await api(name, id);
  return a;
}
