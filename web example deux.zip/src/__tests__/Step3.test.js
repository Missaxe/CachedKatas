import Step3 from '../Step3'

///Read the instruction in the README at the root of the project

describe('Let\s fiddle with functions', () => {
  test('Convert the function in Step 3 to an arrow function', () => {
    const result = Step3()
    expect(result).toBe(1)
  })
})
