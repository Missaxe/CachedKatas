import Step2 from '../Step2'

///Read the instruction in the README at the root of the project

describe('A basic api call', () => {
  test('send the right argument to get the answer', () => {
    const res = Step2()
    expect(res).toEqual({ name: 'serviette', id: 1 })
  })
})
