var emailRegex = /^([\w-\.]+)@((?:[\w]+\.)+)([a-zA-Z]{2,4})/i;

function domReady(fn) {
   if (document.readyState === "complete"
      || (document.readyState !== "loading" && !document.documentElement.doScroll)
   ) {
      fn();
   } else {
      document.addEventListener("DOMContentLoaded", fn)
   }

   const emailField = document.getElementById('mce-EMAIL');
   emailField.addEventListener('blur', function(){
      const emailValue = emailField.value;

      if(!emailRegex.test(emailValue)){
         emailField.style.border = '2px solid red';
      }else{
         emailField.style.border = '';
      }
   });

   document.getElementById("pauseButton").addEventListener("click", function(){
      if(isPaused){
         resumeCountdown();
      }else{
         pauseCountdown();
      }
   });

   document.getElementById('mc-embedded-subscribe').addEventListener('click', function(){
      if(!emailRegex.test(emailField.value)){
         return;
      }

      var data = {
         email : emailField.value
      };

      fetch('/newsletter/subscribe',{
         method: 'POST',
         headers:{
            'Content-Type' : 'application/json'
         },
         body : JSON.stringify(data)
      })
      .then(response => response.json())
      .then(data => {
         if(data.success){
            displayMessage('Subscribed!', 'success');
         }else{
            displayMessage(data.message || 'error!','danger');
         }
      })
      .catch(error => {
         displayMessage('There was an error with the request. Please try again.', 'danger');
      });
   })
}

function displayMessage(message, type) {
   var messageElement = document.getElementById('message');
   messageElement.innerHTML = `
       <div class="alert alert-${type}" role="alert">
           ${message}
       </div>
   `;
}

function pad(num, size) {
   var s = num + "";
   while (s.length < size) s = "0" + s;
   return s;
}

var isPaused = false;
var x;
var distance;

function pauseCountdown() {
   isPaused = true;
   clearInterval(x);
   document.getElementById("pauseButton").textContent = "Resume Countdown";
   document.getElementById("pauseButton").classList.remove("btn-danger");
   document.getElementById("pauseButton").classList.add("btn-success");
}

function resumeCountdown() {
   isPaused = false;
   startCountdown();
   document.getElementById("pauseButton").textContent = "Pause Countdown";
   document.getElementById("pauseButton").classList.remove("btn-success");
   document.getElementById("pauseButton").classList.add("btn-danger");
}

function startCountdown() {
   var today = new Date();
   var endDate = new Date(today.getFullYear(), today.getMonth() + 3, today.getDate() + 15);

   var endDateTicks = endDate.getTime();

   x = setInterval(function () {
      if (!isPaused) {
         today = new Date();
         var todayTicks = today.getTime();
         distance = endDateTicks - todayTicks;

         var days = Math.floor(distance / (1000 * 60 * 60 * 24));
         var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
         var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
         var seconds = Math.floor((distance % (1000 * 60)) / 1000);

         var timer = document.querySelector('#time');

         timer.innerHTML = '<div class="col-xs-6 col-sm-6 col-md-3 lu-countdown-item lu-days"><div class="lu-square"><span>'
            + pad(days, 2)
            + '</span><span>Days</span></div></div><div class="col-xs-6 col-sm-6 col-md-3 lu-countdown-item lu-hours"><div class="lu-square"><span>'
            + pad(hours, 2)
            + '</span><span>Hours</span></div></div><div class="col-xs-6 col-sm-6 col-md-3 lu-countdown-item lu-minutes"><div class="lu-square"><span>'
            + pad(minutes, 2)
            + '</span><span>Minutes</span></div></div><div class="col-xs-6 col-sm-6 col-md-3 lu-countdown-item lu-seconds"><div class="lu-square"><span>'
            + pad(seconds, 2)
            + '</span><span>Seconds</span></div></div>'

         if (distance < 0) {
            clearInterval(x);
            timer.innerHTML = "LAUNCHED";
         }
      }
   }, 1000);
}

domReady(function () {
   startCountdown();
});
